# 32-FUNCTION-BUTTON-BOX

View YouTube Video here for setup instructions
https://youtu.be/Z7Sc4MJ8RPM

Please consider supporting 
https://www.patreon.com/AMSTUDIO

Share the video. 

NON-COMMERCIAL PERSONAL USE ONLY COPYRIGHT AMSTUDIO 2018

This work is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.
https://creativecommons.org/licenses/by-nc-nd/4.0/
